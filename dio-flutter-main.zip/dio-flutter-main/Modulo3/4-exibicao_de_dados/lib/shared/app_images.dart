class AppImages {
  static String get user1 => "lib/images/user1.png";
  static String get user2 => "lib/images/user2.png";
  static String get user3 => "lib/images/user3.png";
  static String get paisagem1 => "lib/images/paisagem1.jpg";
  static String get paisagem2 => "lib/images/paisagem2.jpg";
  static String get paisagem3 => "lib/images/paisagem3.jpg";
}
