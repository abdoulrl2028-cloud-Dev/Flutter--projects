class CardDetail {
  int id;
  String title;
  String url;
  String text;

  CardDetail(this.id, this.title, this.url, this.text);
}
