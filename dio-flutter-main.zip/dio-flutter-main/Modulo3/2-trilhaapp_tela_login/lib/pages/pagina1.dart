import 'package:flutter/material.dart';

class Pagina1Page extends StatefulWidget {
  const Pagina1Page({Key? key}) : super(key: key);

  @override
  State<Pagina1Page> createState() => _Pagina1PageState();
}

class _Pagina1PageState extends State<Pagina1Page> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blueGrey,
    );
  }
}
