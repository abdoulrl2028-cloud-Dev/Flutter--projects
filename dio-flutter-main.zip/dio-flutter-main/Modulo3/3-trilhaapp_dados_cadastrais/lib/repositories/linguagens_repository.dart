class LinguagensRepository {
  List<String> retornaLinguagens() {
    return ["Dart", "C#", "Python", "Java"];
  }
}
