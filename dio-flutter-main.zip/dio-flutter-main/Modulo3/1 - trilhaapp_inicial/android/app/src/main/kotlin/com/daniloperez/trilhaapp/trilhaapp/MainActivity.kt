package com.daniloperez.trilhaapp.trilhaapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
