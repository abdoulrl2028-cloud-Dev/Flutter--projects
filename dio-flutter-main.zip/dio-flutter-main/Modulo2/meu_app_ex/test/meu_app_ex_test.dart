import 'package:meu_app_ex/meu_app_ex.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(42, 42);
  });
}
