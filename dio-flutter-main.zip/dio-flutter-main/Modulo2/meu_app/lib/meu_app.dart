int calculate() {
  return 16 * 7;
}
