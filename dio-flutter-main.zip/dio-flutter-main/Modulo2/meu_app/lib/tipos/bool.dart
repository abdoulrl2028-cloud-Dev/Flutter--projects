void main(List<String> arguments) {
  var varTrue = true;
  bool varFalse = false;

  print(varTrue);
  print(varFalse);
  print(!varTrue);
  print(!varFalse);
  print(varTrue == varFalse);
}
