void main(List<String> arguments) {
  const String variavel = "ABC";
  const int variavel1 = 1;
  const bool variavel2 = true;
  print(variavel);
}
