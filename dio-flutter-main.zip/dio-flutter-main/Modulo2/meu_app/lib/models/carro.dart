class Carro {
  int _rodas = 0;
  String _cor = "";

  Carro(String cor, int rodas) {
    this._cor = cor;
    this._rodas = rodas;
  }
}
