import 'package:meu_app/meu_app.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 112);
  });
}
