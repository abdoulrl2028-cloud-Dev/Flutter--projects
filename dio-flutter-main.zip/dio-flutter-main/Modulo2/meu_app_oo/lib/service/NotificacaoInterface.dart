import 'package:meu_app_oo/classes/pessoa_abstract.dart';

abstract class NotificacaoInterface {
  void enviarNotificacao(Pessoa pessoa);
}
